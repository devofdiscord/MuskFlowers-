module.exports = {
  PORT: 5000,
  MONGO_URI: "mongodb://localhost:27017/muskflowers",
  GOOGLE_CLIENT_ID: "1089122338198-be1ukp1li5hgm2cq0u98e6r018a1aofo.apps.googleusercontent.com",
  GOOGLE_CLIENT_SECRET: "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",
  CALLBACK_URL: "https://muskflowers.netlify.app/auth/google/callback"
};